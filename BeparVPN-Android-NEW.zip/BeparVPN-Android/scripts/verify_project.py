#!/usr/bin/env python3
"""Fast structural checks for the Bepar Android source tree (not a substitute for Android builds)."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


manifest_path = ROOT / "app/src/main/AndroidManifest.xml"
try:
    manifest = ET.parse(manifest_path).getroot()
except Exception as exc:  # malformed XML must fail CI early
    errors.append(f"AndroidManifest.xml could not be parsed: {exc}")
    manifest = None

if manifest is not None:
    android_ns = "{http://schemas.android.com/apk/res/android}"
    app = manifest.find("application")
    require(app is not None, "Manifest application element is missing")
    if app is not None:
        require(app.get(android_ns + "icon") == "@mipmap/ic_launcher", "App launcher icon is not configured")
        services = app.findall("service")
        require(any((item.get(android_ns + "permission") == "android.permission.BIND_VPN_SERVICE") for item in services), "VpnService binding permission is missing")
        require(any((item.get(android_ns + "foregroundServiceType") == "systemExempted") for item in services), "Android 14+ VPN foreground-service type is missing")

required_files = [
    "app/src/main/java/com/bepar/vpn/MainActivity.kt",
    "app/src/main/java/com/bepar/vpn/core/XrayApi.kt",
    "app/src/main/java/com/bepar/vpn/core/XrayConfigBuilder.kt",
    "app/src/main/java/com/bepar/vpn/core/TunnelProbe.kt",
    "app/src/main/java/com/bepar/vpn/data/NodeStore.kt",
    "app/src/main/java/com/bepar/vpn/vpn/BeparVpnService.kt",
    "app/src/main/assets/geoip.dat",
    "app/src/main/assets/geosite.dat",
    ".github/workflows/build-apk.yml",
]
for relative in required_files:
    path = ROOT / relative
    require(path.is_file() and path.stat().st_size > 0, f"Required file missing or empty: {relative}")

# All Android resource XML must be well-formed, including launcher icons.
for xml_path in (ROOT / "app/src/main/res").rglob("*.xml"):
    try:
        ET.parse(xml_path)
    except Exception as exc:
        errors.append(f"Invalid resource XML {xml_path.relative_to(ROOT)}: {exc}")

require((ROOT / "app/src/main/res/mipmap-mdpi/ic_launcher.png").is_file(), "Legacy launcher icon fallback is missing")
require((ROOT / "app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml").is_file(), "Adaptive launcher icon is missing")

for relative in ("app/src/main/assets/geoip.dat", "app/src/main/assets/geosite.dat"):
    path = ROOT / relative
    if path.exists():
        require(path.stat().st_size > 1024, f"Geo asset unexpectedly small: {relative}")

main_source = (ROOT / "app/src/main/java/com/bepar/vpn/MainActivity.kt").read_text(encoding="utf-8")
service_source = (ROOT / "app/src/main/java/com/bepar/vpn/vpn/BeparVpnService.kt").read_text(encoding="utf-8")
store_source = (ROOT / "app/src/main/java/com/bepar/vpn/data/NodeStore.kt").read_text(encoding="utf-8")
builder_source = (ROOT / "app/src/main/java/com/bepar/vpn/core/XrayConfigBuilder.kt").read_text(encoding="utf-8")
api_source = (ROOT / "app/src/main/java/com/bepar/vpn/core/XrayApi.kt").read_text(encoding="utf-8")

require("VpnService.prepare" in main_source, "VPN permission preparation is missing")
require("VpnService.protect" in service_source or ".protect(" in service_source, "Xray socket protection callback is missing")
require('"runXray"' in service_source and '"stopXray"' in service_source, "Xray lifecycle methods are missing")
require('"xray.tun.fd"' in builder_source, "Android TUN file descriptor is not passed to Xray")
require("AES/GCM/NoPadding" in store_source and "AndroidKeyStore" in store_source, "Encrypted profile storage is missing")
require("convertShareLinksToXrayJson" in api_source, "libXray share-link conversion is missing")
require("TunnelProbe.run()" in main_source, "In-app tunnel connectivity test is missing")
require("POST_NOTIFICATIONS" in main_source, "Android 13+ notification permission flow is missing")
require("readConfigFile" in main_source and "15 * 1024 * 1024" in main_source, "Bounded text-file import is missing")
require("BEPAR  •  ANDROID CLIENT" in main_source, "Subtle Bepar developer mark is missing")

# Do not accidentally ship a Windows executable in the Android package source.
exe_files = list((ROOT / "app").rglob("*.exe"))
require(not exe_files, "Windows executable found under app/: " + ", ".join(str(p.relative_to(ROOT)) for p in exe_files))

if errors:
    print("PROJECT CHECK FAILED")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)

print(f"Project structural check passed ({len(required_files)} required files, manifest and key integration markers).")
print("Note: this is not an Android compilation, emulator test, or real VPN connectivity test.")
