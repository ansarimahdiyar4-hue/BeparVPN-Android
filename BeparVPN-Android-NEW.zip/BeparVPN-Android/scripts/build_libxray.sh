#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK="${TMPDIR:-/tmp}/bepar-libxray-build"

if [[ -z "${ANDROID_HOME:-}" ]]; then
  echo "ANDROID_HOME is not set. Install Android SDK first." >&2
  exit 1
fi
if [[ -z "${ANDROID_NDK_HOME:-}" ]]; then
  echo "ANDROID_NDK_HOME is not set. Install Android NDK first." >&2
  exit 1
fi

rm -rf "$WORK"
git clone --depth 1 --branch v26.10.31 https://github.com/XTLS/libXray.git "$WORK"
(
  cd "$WORK"
  python3 build/main.py android
  test -s libXray.aar
  mkdir -p "$ROOT/app/libs"
  cp libXray.aar "$ROOT/app/libs/libXray.aar"
)

echo "Created: $ROOT/app/libs/libXray.aar"
