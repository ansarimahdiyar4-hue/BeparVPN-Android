# libXray is packaged as a native AAR. No additional rules are required for debug builds.
