package com.bepar.vpn.data

data class ServerNode(
    val id: String,
    val name: String,
    val protocol: String,
    val host: String,
    /** Xray outbound JSON only. The VPN service wraps it in a complete Xray config. */
    val outboundJson: String
)
