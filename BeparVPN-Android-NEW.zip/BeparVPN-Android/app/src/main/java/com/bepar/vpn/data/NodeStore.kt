package com.bepar.vpn.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores profiles encrypted with an AES-256-GCM key held by Android Keystore.
 * The key itself is never written to app preferences or exported from Keystore.
 */
object NodeStore {
    private const val PREFS = "bepar_secure_store"
    private const val BLOB_KEY = "profiles_blob_v1"
    private const val KEY_ALIAS = "bepar_vpn_profiles_aes_gcm"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_TAG_BITS = 128
    private const val GCM_IV_BYTES = 12

    @Synchronized
    fun load(context: Context): List<ServerNode> {
        val blob = prefs(context).getString(BLOB_KEY, null) ?: return emptyList()
        return try {
            val root = JSONObject(decrypt(blob))
            val array = root.optJSONArray("profiles") ?: JSONArray()
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val id = item.optString("id")
                    val outbound = item.optString("outbound")
                    if (id.isBlank() || outbound.isBlank()) continue
                    add(
                        ServerNode(
                            id = id,
                            name = item.optString("name", "سرور بدون نام"),
                            protocol = item.optString("protocol", "xray"),
                            host = item.optString("host", ""),
                            outboundJson = outbound
                        )
                    )
                }
            }
        } catch (_: Exception) {
            // A corrupted/invalidated Keystore key must not crash the VPN UI.
            emptyList()
        }
    }

    @Synchronized
    fun selectedId(context: Context): String? {
        val blob = prefs(context).getString(BLOB_KEY, null) ?: return null
        return try {
            JSONObject(decrypt(blob)).optString("selectedId").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

    @Synchronized
    fun selected(context: Context): ServerNode? {
        val id = selectedId(context) ?: return null
        return load(context).firstOrNull { it.id == id }
    }

    @Synchronized
    fun save(context: Context, profiles: List<ServerNode>, selectedId: String?) {
        val root = JSONObject().put("selectedId", selectedId ?: "")
        val array = JSONArray()
        profiles.forEach { profile ->
            array.put(
                JSONObject()
                    .put("id", profile.id)
                    .put("name", profile.name)
                    .put("protocol", profile.protocol)
                    .put("host", profile.host)
                    .put("outbound", profile.outboundJson)
            )
        }
        root.put("profiles", array)
        val encrypted = encrypt(root.toString())
        prefs(context).edit().putString(BLOB_KEY, encrypted).apply()
    }

    @Synchronized
    fun add(context: Context, nodes: List<ServerNode>): Pair<List<ServerNode>, String?> {
        val old = load(context)
        val combined = (old + nodes).distinctBy { it.outboundJson }
        val previousSelection = selectedId(context)
        val newSelection = previousSelection?.takeIf { id -> combined.any { it.id == id } }
            ?: combined.firstOrNull()?.id
        save(context, combined, newSelection)
        return combined to newSelection
    }

    @Synchronized
    fun select(context: Context, id: String?) {
        save(context, load(context), id)
    }

    @Synchronized
    fun remove(context: Context, id: String): Pair<List<ServerNode>, String?> {
        val current = load(context).filterNot { it.id == id }
        val selection = selectedId(context).let { selected ->
            if (selected == id) current.firstOrNull()?.id else selected
        }
        save(context, current, selection)
        return current to selection
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(plainText: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val cipherText = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        val combined = cipher.iv + cipherText
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    private fun decrypt(encoded: String): String {
        val combined = Base64.decode(encoded, Base64.NO_WRAP)
        require(combined.size > GCM_IV_BYTES) { "Encrypted profile data is truncated" }
        val iv = combined.copyOfRange(0, GCM_IV_BYTES)
        val cipherText = combined.copyOfRange(GCM_IV_BYTES, combined.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(GCM_TAG_BITS, iv))
        return cipher.doFinal(cipherText).toString(Charsets.UTF_8)
    }

    fun newId(): String = UUID.randomUUID().toString()
}
