package com.bepar.vpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkRequest
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import com.bepar.vpn.MainActivity
import com.bepar.vpn.core.XrayApi
import com.bepar.vpn.core.XrayConfigBuilder
import com.bepar.vpn.data.NodeStore
import libXray.DialerController
import libXray.LibXray
import org.json.JSONObject
import java.io.File
import java.util.LinkedHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Android TUN owner. Xray runs in-process through the official libXray AAR;
 * no Windows executable is copied or launched on Android.
 */
class BeparVpnService : VpnService() {
    companion object {
        const val ACTION_CONNECT = "com.bepar.vpn.action.CONNECT"
        const val ACTION_DISCONNECT = "com.bepar.vpn.action.DISCONNECT"
        const val EXTRA_NODE_ID = "node_id"

        private const val CHANNEL_ID = "bepar_vpn_connection"
        private const val NOTIFICATION_ID = 4107
    }

    private val worker = Executors.newSingleThreadExecutor()
    private val reconnectQueued = AtomicBoolean(false)

    @Volatile private var tunDescriptor: ParcelFileDescriptor? = null
    @Volatile private var coreStarted = false
    @Volatile private var coreStartAttempted = false
    @Volatile private var activeConfigJson: String? = null
    @Volatile private var activePhysicalNetwork: Network? = null
    private val physicalNetworks = LinkedHashMap<Network, Boolean>()
    @Volatile private var callbackRegistered = false

    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    private val socketController = object : DialerController {
        // gomobile maps Go int to Java long. Android VpnService.protect expects Int.
        override fun protectFd(fd: Long): Boolean {
            return this@BeparVpnService.protect(fd.toInt())
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        connectivityManager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT -> {
                worker.execute { disconnectInternal(stopService = true) }
                return START_NOT_STICKY
            }
            ACTION_CONNECT, null -> {
                val nodeId = intent?.getStringExtra(EXTRA_NODE_ID)
                    ?: NodeStore.selectedId(this)
                if (nodeId.isNullOrBlank()) {
                    ConnectionState.update(VpnPhase.ERROR, "ابتدا یک سرور اضافه و انتخاب کن.")
                    stopSelf(startId)
                    return START_NOT_STICKY
                }

                beginConnect(nodeId, startId)
                return START_STICKY
            }
            else -> {
                stopSelf(startId)
                return START_NOT_STICKY
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return if (intent?.action == SERVICE_INTERFACE) super.onBind(intent) else null
    }

    override fun onRevoke() {
        worker.execute { disconnectInternal(stopService = true) }
        super.onRevoke()
    }

    override fun onDestroy() {
        unregisterNetworkCallbackSafely()
        worker.execute { disconnectInternal(stopService = false) }
        worker.shutdown()
        super.onDestroy()
    }

    /** Establish the Android interface before declaring the system-exempted FGS.
     * Android permits this foreground-service type for an active VPN app. */
    private fun beginConnect(nodeId: String, startId: Int) {
        try {
            if (tunDescriptor == null) {
                captureInitialPhysicalNetwork()
                tunDescriptor = establishTun()
            }
            startAsForeground("در حال آماده‌سازی اتصال…")
            worker.execute { connectNode(nodeId) }
        } catch (error: Exception) {
            releaseCoreAndTun()
            val reason = error.message?.take(180)?.ifBlank { null } ?: "ساخت رابط VPN ناموفق بود."
            ConnectionState.update(VpnPhase.ERROR, reason)
            stopSelf(startId)
        }
    }

    private fun connectNode(nodeId: String) {
        try {
            ConnectionState.update(VpnPhase.CONNECTING, "در حال برقراری تونل…")
            updateNotification("در حال برقراری تونل…")

            // A profile switch keeps Android's TUN fd but replaces the Xray runtime.
            stopCoreOnly()

            val node = NodeStore.load(this).firstOrNull { it.id == nodeId }
                ?: throw IllegalArgumentException("پروفایل انتخاب‌شده پیدا نشد.")

            val tun = tunDescriptor
                ?: throw IllegalStateException("رابط VPN آماده نیست؛ دوباره تلاش کن.")
            val assetDir = prepareGeoAssets()

            // Protect every Xray-created socket so it uses the physical network,
            // not the TUN interface that Xray itself is consuming.
            LibXray.registerDialerController(socketController)
            LibXray.registerListenerController(socketController)
            LibXray.setDNS(socketController, "1.1.1.1:53")

            val config = XrayConfigBuilder.build(
                outboundJson = node.outboundJson,
                tunFd = tun.fd,
                assetDirectory = assetDir.absolutePath
            )
            activeConfigJson = config

            coreStartAttempted = true
            XrayApi.invoke(
                "runXray",
                JSONObject().put("xrayJson", config)
            )
            coreStarted = true

            // Verify the managed Core state instead of treating an accepted request
            // as proof that a live tunnel is already running.
            val state = XrayApi.invoke("getXrayState").optJSONObject("data")
            if (state != null && !state.optBoolean("running", false)) {
                throw IllegalStateException("هسته Xray اجرا نشد.")
            }

            registerNetworkCallback()
            ConnectionState.update(VpnPhase.CONNECTED, "هسته Xray فعال است؛ برای اطمینان، اینترنت از تونل را آزمایش کن.")
            updateNotification("متصل • ${node.name}")
        } catch (error: Exception) {
            releaseCoreAndTun()
            unregisterNetworkCallbackSafely()
            val reason = error.message?.take(180)?.ifBlank { null } ?: "خطای ناشناخته در اتصال"
            ConnectionState.update(VpnPhase.ERROR, reason)
            updateNotification("اتصال ناموفق بود")
            stopForeground(true)
            stopSelf()
        }
    }

    private fun establishTun(): ParcelFileDescriptor {
        val builder = Builder()
            .setSession("Bepar VPN")
            .setMtu(XrayConfigBuilder.TUN_MTU)
            .addAddress("10.77.0.1", 32)
            .addAddress("fd42:be:77::1", 128)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("2606:4700:4700::1111")

        return builder.establish()
            ?: throw IllegalStateException("Android اجازه ساخت رابط VPN را نداد.")
    }

    private fun prepareGeoAssets(): File {
        val target = File(filesDir, "xray-assets")
        if (!target.exists() && !target.mkdirs()) {
            throw IllegalStateException("ساخت پوشه داده‌های Xray ناموفق بود.")
        }

        listOf("geoip.dat", "geosite.dat").forEach { filename ->
            val output = File(target, filename)
            if (!output.exists() || output.length() == 0L) {
                assets.open(filename).use { input ->
                    output.outputStream().use { out -> input.copyTo(out) }
                }
            }
        }
        return target
    }

    private fun captureInitialPhysicalNetwork() {
        val manager = connectivityManager ?: return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val active = manager.activeNetwork ?: return
        val capabilities = manager.getNetworkCapabilities(active) ?: return
        if (capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        ) {
            synchronized(physicalNetworks) {
                physicalNetworks[active] = capabilities.hasCapability(
                    NetworkCapabilities.NET_CAPABILITY_VALIDATED
                )
                activePhysicalNetwork = active
            }
        }
    }

    private fun registerNetworkCallback() {
        if (callbackRegistered) return
        val manager = connectivityManager ?: return
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                val capabilities = manager.getNetworkCapabilities(network) ?: return
                updatePhysicalNetwork(network, capabilities)
            }

            override fun onCapabilitiesChanged(
                network: Network,
                networkCapabilities: NetworkCapabilities
            ) {
                updatePhysicalNetwork(network, networkCapabilities)
            }

            override fun onLost(network: Network) {
                val changed = synchronized(physicalNetworks) {
                    physicalNetworks.remove(network)
                    if (activePhysicalNetwork == network) {
                        activePhysicalNetwork = physicalNetworks.entries
                            .maxByOrNull { it.value }
                            ?.key
                        true
                    } else {
                        false
                    }
                }
                if (changed && coreStarted) queueReconnect()
            }
        }

        networkCallback = callback
        try {
            manager.registerNetworkCallback(request, callback)
            callbackRegistered = true
        } catch (_: Exception) {
            // The tunnel remains usable; monitoring is an optional recovery aid.
        }
    }

    private fun updatePhysicalNetwork(network: Network, capabilities: NetworkCapabilities) {
        if (!capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN) ||
            !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        ) return

        val validated = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        val changed = synchronized(physicalNetworks) {
            physicalNetworks[network] = validated
            val current = activePhysicalNetwork
            val currentValidated = current?.let { physicalNetworks[it] } ?: false
            if (current == null || (!currentValidated && validated)) {
                activePhysicalNetwork = network
                true
            } else {
                false
            }
        }
        if (changed && coreStarted) queueReconnect()
    }

    private fun queueReconnect() {
        if (!reconnectQueued.compareAndSet(false, true)) return
        ConnectionState.update(VpnPhase.RECONNECTING, "تغییر شبکه؛ در حال اتصال مجدد…")
        updateNotification("تغییر شبکه؛ در حال اتصال مجدد…")
        worker.execute {
            try {
                val config = activeConfigJson ?: return@execute
                if (!coreStarted) return@execute
                XrayApi.invoke("stopXray")
                coreStarted = false
                coreStartAttempted = false
                LibXray.resetDNS()
                Thread.sleep(350)
                LibXray.setDNS(socketController, "1.1.1.1:53")
                coreStartAttempted = true
                XrayApi.invoke("runXray", JSONObject().put("xrayJson", config))
                coreStarted = true
                ConnectionState.update(VpnPhase.CONNECTED, "هسته Xray دوباره فعال شد؛ دسترسی اینترنت را آزمایش کن.")
                updateNotification("متصل • بپر VPN")
            } catch (error: Exception) {
                releaseCoreAndTun()
                unregisterNetworkCallbackSafely()
                ConnectionState.update(
                    VpnPhase.ERROR,
                    error.message?.take(180) ?: "اتصال پس از تغییر شبکه برقرار نشد."
                )
                updateNotification("نیاز به اتصال مجدد")
                stopForeground(true)
                stopSelf()
            } finally {
                reconnectQueued.set(false)
            }
        }
    }

    private fun stopCoreOnly() {
        if (coreStartAttempted || coreStarted) {
            try {
                XrayApi.invoke("stopXray")
            } catch (_: Exception) {
                // Continue releasing DNS state even if Core shutdown reports an error.
            }
        }
        coreStarted = false
        coreStartAttempted = false
        try {
            LibXray.resetDNS()
        } catch (_: Exception) {
            // DNS resolver may not have been installed yet.
        }
    }

    private fun releaseCoreAndTun() {
        stopCoreOnly()
        activeConfigJson = null
        try {
            tunDescriptor?.close()
        } catch (_: Exception) {
            // Descriptor may already be closed by Android.
        }
        tunDescriptor = null
    }

    private fun disconnectInternal(stopService: Boolean) {
        releaseCoreAndTun()
        unregisterNetworkCallbackSafely()
        ConnectionState.update(VpnPhase.DISCONNECTED, "اتصال قطع شد")
        stopForeground(true)
        if (stopService) stopSelf()
    }

    private fun unregisterNetworkCallbackSafely() {
        val manager = connectivityManager
        val callback = networkCallback
        if (callbackRegistered && manager != null && callback != null) {
            try {
                manager.unregisterNetworkCallback(callback)
            } catch (_: Exception) {
                // No action needed if Android already unregistered the callback.
            }
        }
        callbackRegistered = false
        networkCallback = null
        synchronized(physicalNetworks) {
            physicalNetworks.clear()
            activePhysicalNetwork = null
        }
    }

    private fun startAsForeground(message: String) {
        val notification = buildNotification(message)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(message: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(message))
    }

    private fun buildNotification(message: String): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val disconnect = PendingIntent.getService(
            this,
            2,
            Intent(this, BeparVpnService::class.java).setAction(ACTION_DISCONNECT),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("بپر VPN")
            .setContentText(message)
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "قطع اتصال", disconnect)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "وضعیت اتصال VPN",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "اعلان دائمی هنگام فعال بودن تونل VPN"
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }
}
