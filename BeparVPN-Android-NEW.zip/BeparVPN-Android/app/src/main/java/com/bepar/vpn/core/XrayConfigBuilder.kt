package com.bepar.vpn.core

import org.json.JSONArray
import org.json.JSONObject

object XrayConfigBuilder {
    const val TUN_MTU = 1400

    fun build(outboundJson: String, tunFd: Int, assetDirectory: String): String {
        require(tunFd >= 0) { "Invalid TUN file descriptor" }
        val proxyOutbound = JSONObject(outboundJson)
        val protocol = proxyOutbound.optString("protocol")
        require(protocol.isNotBlank()) { "پروتکل سرور در کانفیگ مشخص نیست." }
        proxyOutbound.put("tag", "proxy")

        val outbounds = JSONArray()
            .put(proxyOutbound)
            .put(
                JSONObject()
                    .put("tag", "direct")
                    .put("protocol", "freedom")
                    .put("settings", JSONObject())
            )
            .put(
                JSONObject()
                    .put("tag", "block")
                    .put("protocol", "blackhole")
                    .put("settings", JSONObject())
            )

        val inbound = JSONObject()
            .put("tag", "bepar-tun")
            .put("protocol", "tun")
            .put("port", 0)
            .put(
                "settings",
                JSONObject()
                    .put("name", "bepar0")
                    .put("mtu", TUN_MTU)
            )

        val routingRule = JSONObject()
            .put("type", "field")
            .put("inboundTag", JSONArray().put("bepar-tun"))
            .put("outboundTag", "proxy")

        return JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put(
                "env",
                JSONObject()
                    // libXray's current Android integration reads the externally-owned TUN fd here.
                    .put("xray.tun.fd", tunFd.toString())
                    .put("XRAY_LOCATION_ASSET", assetDirectory)
            )
            .put("inbounds", JSONArray().put(inbound))
            .put("outbounds", outbounds)
            .put(
                "routing",
                JSONObject()
                    .put("domainStrategy", "AsIs")
                    .put("rules", JSONArray().put(routingRule))
            )
            .put(
                "dns",
                JSONObject()
                    .put("servers", JSONArray().put("1.1.1.1").put("8.8.8.8"))
                    .put("queryStrategy", "UseIP")
            )
            .toString()
    }
}
