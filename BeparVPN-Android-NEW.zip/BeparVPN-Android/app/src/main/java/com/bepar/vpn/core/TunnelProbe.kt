package com.bepar.vpn.core

import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * Checks whether ordinary app traffic can reach public HTTPS endpoints while
 * the Android VPN is active. The probe is intentionally small and sends no
 * user data; it is a connectivity check, not a speed test.
 */
data class TunnelProbeResult(
    val reachable: Boolean,
    val latencyMillis: Long?,
    val endpoint: String?,
    val detail: String
)

object TunnelProbe {
    private val endpoints = listOf(
        "https://cp.cloudflare.com/generate_204",
        "https://connectivitycheck.gstatic.com/generate_204"
    )

    fun run(): TunnelProbeResult {
        var lastError = "اتصال به مقصدهای بررسی برقرار نشد."
        for (endpoint in endpoints) {
            var connection: HttpsURLConnection? = null
            val startedAt = System.nanoTime()
            try {
                connection = (URL(endpoint).openConnection() as HttpsURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 5_000
                    readTimeout = 5_000
                    instanceFollowRedirects = false
                    useCaches = false
                    setRequestProperty("Cache-Control", "no-cache")
                    setRequestProperty("User-Agent", "BeparVPN-Android/1.1")
                }
                val code = connection.responseCode
                val elapsed = (System.nanoTime() - startedAt) / 1_000_000L
                if (code in 200..299) {
                    return TunnelProbeResult(
                        reachable = true,
                        latencyMillis = elapsed,
                        endpoint = URL(endpoint).host,
                        detail = "دسترسی HTTPS از مسیر VPN تأیید شد."
                    )
                }
                lastError = "پاسخ مقصد بررسی: HTTP $code"
            } catch (error: Exception) {
                lastError = error.message?.take(120) ?: "بررسی شبکه ناموفق بود."
            } finally {
                connection?.disconnect()
            }
        }
        return TunnelProbeResult(
            reachable = false,
            latencyMillis = null,
            endpoint = null,
            detail = lastError
        )
    }
}
