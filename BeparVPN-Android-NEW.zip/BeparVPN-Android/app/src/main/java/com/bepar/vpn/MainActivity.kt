package com.bepar.vpn

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.bepar.vpn.core.XrayApi
import com.bepar.vpn.core.TunnelProbe
import com.bepar.vpn.data.NodeStore
import com.bepar.vpn.data.ServerNode
import com.bepar.vpn.vpn.BeparVpnService
import com.bepar.vpn.vpn.ConnectionState
import com.bepar.vpn.vpn.VpnPhase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Night = Color(0xFF071426)
private val DeepBlue = Color(0xFF0B1D38)
private val Panel = Color(0xFF102746)
private val PanelLight = Color(0xFF17365B)
private val Cyan = Color(0xFF22C7F4)
private val ElectricBlue = Color(0xFF3478FF)
private val Mint = Color(0xFF42E6A4)
private val Muted = Color(0xFF91A8C4)
private val Danger = Color(0xFFFF727D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 20, 38)
        window.navigationBarColor = android.graphics.Color.rgb(7, 20, 38)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan,
                    onPrimary = Color(0xFF001521),
                    secondary = Mint,
                    background = Night,
                    surface = Panel,
                    surfaceVariant = PanelLight,
                    onSurface = Color(0xFFF1F7FF),
                    onSurfaceVariant = Muted,
                    error = Danger
                )
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    BeparApp()
                }
            }
        }
    }
}

private enum class AppTab { HOME, PROFILES, STATUS, SETTINGS }

@Composable
private fun BeparApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val vpnState by ConnectionState.state.collectAsState()
    var profiles by remember { mutableStateOf(NodeStore.load(context)) }
    var selectedId by remember { mutableStateOf(NodeStore.selectedId(context)) }
    var activeTab by rememberSaveable { mutableStateOf(AppTab.HOME.name) }
    var importText by rememberSaveable { mutableStateOf("") }
    var isImporting by remember { mutableStateOf(false) }
    var showImport by rememberSaveable { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<ServerNode?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            selectedId?.let { startVpnService(context, it) }
        } else {
            Toast.makeText(context, "مجوز اتصال VPN تأیید نشد.", Toast.LENGTH_LONG).show()
        }
    }

    fun beginVpnConnect() {
        val id = selectedId
        if (id.isNullOrBlank() || profiles.none { it.id == id }) {
            Toast.makeText(context, "ابتدا یک پروفایل انتخاب کن.", Toast.LENGTH_SHORT).show()
            activeTab = AppTab.PROFILES.name
            return
        }
        val prepareIntent = VpnService.prepare(context)
        if (prepareIntent != null) permissionLauncher.launch(prepareIntent)
        else startVpnService(context, id)
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            Toast.makeText(context, "اعلان اتصال غیرفعال می‌ماند؛ می‌توانی از تنظیمات گوشی آن را فعال کنی.", Toast.LENGTH_LONG).show()
        }
        beginVpnConnect()
    }

    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val content = withContext(Dispatchers.IO) {
                        readConfigFile(context, uri)
                    }
                    importText = content
                    showImport = true
                } catch (error: Exception) {
                    Toast.makeText(context, error.message ?: "خواندن فایل ناموفق بود.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun connect() {
        val notificationsAllowed = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (Build.VERSION.SDK_INT >= 33 && !notificationsAllowed) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            beginVpnConnect()
        }
    }

    fun disconnect() {
        val intent = Intent(context, BeparVpnService::class.java).apply {
            action = BeparVpnService.ACTION_DISCONNECT
        }
        context.startService(intent)
    }

    fun importProfiles() {
        if (isImporting || importText.isBlank()) return
        isImporting = true
        scope.launch {
            try {
                val imported = withContext(Dispatchers.IO) { XrayApi.importNodes(importText) }
                val (updated, selected) = NodeStore.add(context, imported)
                profiles = updated
                selectedId = selected
                importText = ""
                showImport = false
                Toast.makeText(context, "${imported.size} پروفایل اضافه شد.", Toast.LENGTH_SHORT).show()
            } catch (error: Exception) {
                Toast.makeText(
                    context,
                    error.message?.take(220) ?: "خواندن کانفیگ ناموفق بود.",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                isImporting = false
            }
        }
    }

    val selectedNode = profiles.firstOrNull { it.id == selectedId }

    Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(DeepBlue, Night, Color(0xFF050D19))))) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Cyan.copy(alpha = 0.045f), radius = size.width * 0.72f, center = Offset(size.width * 0.92f, size.height * 0.12f))
            drawCircle(ElectricBlue.copy(alpha = 0.045f), radius = size.width * 0.58f, center = Offset(size.width * 0.02f, size.height * 0.78f))
        }
        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                BeparBottomBar(
                    activeTab = activeTab,
                    onTab = { activeTab = it.name }
                )
            }
        ) { padding ->
            AnimatedContent(
                targetState = activeTab,
                modifier = Modifier.fillMaxSize().padding(padding),
                label = "bepar-tab-transition",
                transitionSpec = { (fadeIn(tween(190)) + slideInVertically(tween(230)) { it / 18 }) togetherWith fadeOut(tween(120)) }
            ) { tab ->
                when (AppTab.valueOf(tab)) {
                    AppTab.HOME -> HomeScreen(
                        state = vpnState,
                        selectedNode = selectedNode,
                        profileCount = profiles.size,
                        onConnect = ::connect,
                        onDisconnect = ::disconnect,
                        onChooseProfile = { activeTab = AppTab.PROFILES.name }
                    )
                    AppTab.PROFILES -> ProfilesScreen(
                        profiles = profiles,
                        selectedId = selectedId,
                        showImport = showImport,
                        importText = importText,
                        isImporting = isImporting,
                        onToggleImport = { showImport = !showImport },
                        onImportText = { importText = it },
                        onImport = ::importProfiles,
                        onPickFile = { fileLauncher.launch(arrayOf("*/*")) },
                        onSelect = {
                            selectedId = it
                            NodeStore.select(context, it)
                        },
                        onDelete = { deleteTarget = it }
                    )
                    AppTab.STATUS -> StatusScreen(state = vpnState, selectedNode = selectedNode)
                    AppTab.SETTINGS -> SettingsScreen(profileCount = profiles.size)
                }
            }
        }
    }

    if (deleteTarget != null) {
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            containerColor = Panel,
            title = { Text("حذف پروفایل؟", color = Color.White, fontWeight = FontWeight.Bold) },
            text = { Text("«${deleteTarget?.name}» از فهرست حذف شود؟", color = Muted) },
            confirmButton = {
                TextButton(onClick = {
                    val target = deleteTarget
                    if (target != null) {
                        val (updated, selected) = NodeStore.remove(context, target.id)
                        profiles = updated
                        selectedId = selected
                    }
                    deleteTarget = null
                }) { Text("حذف", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("انصراف", color = Muted) } }
        )
    }
}

@Composable
private fun BeparBottomBar(activeTab: String, onTab: (AppTab) -> Unit) {
    Surface(color = Color(0xF20A1B31), shadowElevation = 18.dp, tonalElevation = 0.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomItem("⌂", "خانه", AppTab.HOME, activeTab, onTab)
            BottomItem("▦", "پروفایل‌ها", AppTab.PROFILES, activeTab, onTab)
            BottomItem("◉", "وضعیت", AppTab.STATUS, activeTab, onTab)
            BottomItem("⚙", "تنظیمات", AppTab.SETTINGS, activeTab, onTab)
        }
    }
}

@Composable
private fun BottomItem(icon: String, label: String, tab: AppTab, activeTab: String, onTab: (AppTab) -> Unit) {
    val selected = activeTab == tab.name
    val tint by animateColorAsState(if (selected) Cyan else Muted, label = "nav-color")
    Column(
        modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable(
            interactionSource = remember { MutableInteractionSource() }, indication = null
        ) { onTab(tab) }.padding(horizontal = 13.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(icon, color = tint, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(label, color = tint, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 17.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        content = content
    )
}

@Composable
private fun BrandHeader(kicker: String = "اتصال امن و هوشمند") {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("بپر VPN", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text(kicker, fontSize = 12.sp, color = Muted)
        }
        Box(
            Modifier.size(48.dp).shadow(12.dp, CircleShape).background(Brush.linearGradient(listOf(Cyan, ElectricBlue)), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("✦", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun HomeScreen(
    state: com.bepar.vpn.vpn.VpnUiState,
    selectedNode: ServerNode?,
    profileCount: Int,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onChooseProfile: () -> Unit
) {
    val connected = state.phase == VpnPhase.CONNECTED
    val busy = state.phase == VpnPhase.CONNECTING || state.phase == VpnPhase.RECONNECTING
    val statusColor = when (state.phase) {
        VpnPhase.CONNECTED -> Mint
        VpnPhase.CONNECTING, VpnPhase.RECONNECTING -> Color(0xFFFFC66D)
        VpnPhase.ERROR -> Danger
        VpnPhase.DISCONNECTED -> Muted
    }

    ScreenColumn {
        BrandHeader()
        AnimatedVisibility(visible = true, enter = fadeIn(tween(400)) + slideInVertically { -it / 5 }) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.09f))
            ) {
                Box(Modifier.background(Brush.linearGradient(listOf(Color(0xFF173D69), Color(0xFF0D2545), Color(0xFF0A1B33))))) {
                    Canvas(Modifier.matchParentSize()) {
                        drawCircle(Cyan.copy(alpha = 0.08f), radius = size.width * .46f, center = Offset(size.width * .9f, size.height * .18f))
                    }
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(shape = CircleShape, color = statusColor.copy(alpha = .13f), border = BorderStroke(1.dp, statusColor.copy(alpha = .4f))) {
                            Row(Modifier.padding(horizontal = 13.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                Box(Modifier.size(7.dp).background(statusColor, CircleShape))
                                Text(statusLabel(state.phase), color = statusColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        PowerButton(active = connected, busy = busy, onClick = { if (connected || busy) onDisconnect() else onConnect() })
                        AnimatedContent(targetState = state.message, label = "connection-message") { message ->
                            Text(message, color = Color(0xFFD8E7F8), fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2)
                        }
                        Text(
                            if (connected) "تونل VPN فعال است" else if (busy) "در حال آماده‌سازی تونل" else "برای شروع اتصال لمس کن",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                        Button(
                            onClick = { if (connected || busy) onDisconnect() else onConnect() },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (connected || busy) Color(0xFF8A3447) else Cyan,
                                contentColor = Color.White
                            )
                        ) {
                            Text(if (connected || busy) "قطع اتصال" else "اتصال به VPN", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                    }
                }
            }
        }

        SectionTitle("سرور انتخاب‌شده", "مدیریت پروفایل‌ها")
        Card(
            modifier = Modifier.fillMaxWidth().clickable(onClick = onChooseProfile),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Panel),
            border = BorderStroke(1.dp, Color.White.copy(alpha = .07f))
        ) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).background(Color(0xFF16436A), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Text("◈", color = Cyan, fontSize = 24.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(selectedNode?.name ?: "هنوز سروری انتخاب نشده", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(
                        selectedNode?.let { "${it.protocol.uppercase()}  •  ${it.host.ifBlank { "آدرس نامشخص" }}" } ?: "$profileCount پروفایل ذخیره‌شده",
                        color = Muted,
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }
                Text("‹", color = Cyan, fontSize = 28.sp)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MiniInfoCard(Modifier.weight(1f), "پروفایل‌ها", profileCount.toString(), "▦")
            MiniInfoCard(Modifier.weight(1f), "موتور اتصال", "Xray", "◉")
        }
        Text("اتصال واقعی به سرور پس از اجرای موفق هسته و عبور ترافیک از تونل قابل تأیید است؛ کیفیت نهایی به سرور و شبکه بستگی دارد.", color = Muted, fontSize = 11.sp, lineHeight = 17.sp)
        SignatureMark()
    }
}

@Composable
private fun PowerButton(active: Boolean, busy: Boolean, onClick: () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "power-pulse")
    val pulse by infinite.animateFloat(
        initialValue = .92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse-scale"
    )
    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(12000, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "ring-rotation"
    )
    val ringColor = if (active) Mint else Cyan
    val scale by animateFloatAsState(if (busy) 1.04f else 1f, label = "button-scale")
    Box(Modifier.size(184.dp).graphicsLayer(scaleX = scale, scaleY = scale).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = size.minDimension * .39f
            drawCircle(ringColor.copy(alpha = .09f), radius = radius * pulse, center = center)
            drawCircle(ringColor.copy(alpha = .18f), radius = radius * 1.19f, center = center, style = Stroke(width = 2.dp.toPx()))
            drawArc(
                brush = Brush.sweepGradient(listOf(Color.Transparent, ringColor, ElectricBlue, Color.Transparent)),
                startAngle = rotation,
                sweepAngle = 115f,
                useCenter = false,
                topLeft = Offset(center.x - radius * 1.12f, center.y - radius * 1.12f),
                size = androidx.compose.ui.geometry.Size(radius * 2.24f, radius * 2.24f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )
            drawCircle(Brush.radialGradient(listOf(Color(0xFF1D4E85), Color(0xFF0A1D37)), center, radius), radius = radius, center = center)
            drawCircle(ringColor.copy(alpha = .8f), radius = radius, center = center, style = Stroke(width = 2.2.dp.toPx()))
        }
        Box(
            Modifier.size(114.dp).shadow(15.dp, CircleShape).background(Brush.linearGradient(listOf(Color(0xFF1C416B), Color(0xFF102746))), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(targetState = busy, label = "power-content") { loading ->
                if (loading) {
                    androidx.compose.material3.CircularProgressIndicator(modifier = Modifier.size(42.dp), color = Cyan, strokeWidth = 3.dp)
                } else {
                    Text("⏻", color = ringColor, fontSize = 58.sp, fontWeight = FontWeight.Light)
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, action: String? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        if (action != null) Text(action, color = Cyan, fontSize = 11.sp)
    }
}

@Composable
private fun MiniInfoCard(modifier: Modifier, label: String, value: String, icon: String) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(label, color = Muted, fontSize = 11.sp)
                Text(value, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
            Text(icon, color = Cyan, fontSize = 24.sp)
        }
    }
}

@Composable
private fun ProfilesScreen(
    profiles: List<ServerNode>,
    selectedId: String?,
    showImport: Boolean,
    importText: String,
    isImporting: Boolean,
    onToggleImport: () -> Unit,
    onImportText: (String) -> Unit,
    onImport: () -> Unit,
    onPickFile: () -> Unit,
    onSelect: (String) -> Unit,
    onDelete: (ServerNode) -> Unit
) {
    ScreenColumn {
        BrandHeader("پروفایل‌ها و اشتراک‌ها")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            SectionTitle("سرورهای من")
            Text("${profiles.size} مورد", color = Muted, fontSize = 11.sp)
        }
        Card(
            modifier = Modifier.fillMaxWidth().clickable(onClick = onToggleImport),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = PanelLight),
            border = BorderStroke(1.dp, Cyan.copy(alpha = .17f))
        ) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("＋", color = Cyan, fontSize = 28.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("افزودن پروفایل جدید", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("لینک سرور، اشتراک یا فایل کانفیگ", color = Muted, fontSize = 11.sp)
                }
                Text(if (showImport) "−" else "＋", color = Cyan, fontSize = 22.sp)
            }
        }
        AnimatedVisibility(showImport, enter = fadeIn() + scaleIn(), exit = fadeOut()) {
            ImportCard(
                value = importText,
                importing = isImporting,
                onValueChange = onImportText,
                onImport = onImport,
                onPickFile = onPickFile
            )
        }
        if (profiles.isEmpty()) {
            EmptyState("هنوز پروفایلی نداری", "یک لینک VLESS، VMess، Trojan، Shadowsocks یا Hysteria2 وارد کن.")
        } else {
            profiles.forEach { node ->
                ProfileCard(
                    node = node,
                    selected = node.id == selectedId,
                    onSelect = { onSelect(node.id) },
                    onDelete = { onDelete(node) }
                )
            }
        }
        Text("پروفایل‌ها به‌صورت رمزگذاری‌شده روی همین دستگاه نگهداری می‌شوند.", color = Muted, fontSize = 11.sp)
        SignatureMark()
    }
}

@Composable
private fun ImportCard(
    value: String,
    importing: Boolean,
    onValueChange: (String) -> Unit,
    onImport: () -> Unit,
    onPickFile: () -> Unit
) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Text("ورود اطلاعات سرور", color = Color.White, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                minLines = 4,
                maxLines = 8,
                shape = RoundedCornerShape(14.dp),
                label = { Text("لینک، URL اشتراک یا Xray JSON") },
                placeholder = { Text("vless://…", style = TextStyle(textDirection = TextDirection.Ltr)) },
                textStyle = TextStyle(color = Color.White, fontSize = 12.sp, textDirection = TextDirection.Ltr),
                keyboardOptions = KeyboardOptions(autoCorrect = false)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Button(onClick = onPickFile, modifier = Modifier.weight(1f).height(47.dp), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = PanelLight)) {
                    Text("انتخاب فایل", color = Color.White, fontSize = 12.sp)
                }
                Button(onClick = onImport, enabled = value.isNotBlank() && !importing, modifier = Modifier.weight(1f).height(47.dp), shape = RoundedCornerShape(13.dp)) {
                    Text(if (importing) "در حال بررسی…" else "بررسی و افزودن", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ProfileCard(node: ServerNode, selected: Boolean, onSelect: () -> Unit, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onSelect),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF123B53) else Panel),
        border = BorderStroke(1.dp, if (selected) Cyan.copy(alpha = .65f) else Color.White.copy(alpha = .06f))
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).background(if (selected) Cyan.copy(alpha = .15f) else PanelLight, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                Text(if (selected) "✓" else "◈", color = if (selected) Mint else Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(node.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, fontSize = 13.sp)
                Text("${node.protocol.uppercase()}  •  ${node.host.ifBlank { "میزبان ثبت نشده" }}", color = Muted, maxLines = 1, fontSize = 10.sp)
            }
            TextButton(onClick = onDelete) { Text("حذف", color = Danger, fontSize = 11.sp) }
        }
    }
}

@Composable
private fun StatusScreen(state: com.bepar.vpn.vpn.VpnUiState, selectedNode: ServerNode?) {
    val scope = rememberCoroutineScope()
    var isTesting by remember { mutableStateOf(false) }
    var probeMessage by remember { mutableStateOf<String?>(null) }
    var probeSuccess by remember { mutableStateOf<Boolean?>(null) }
    var probeLatency by remember { mutableStateOf<Long?>(null) }
    ScreenColumn {
        BrandHeader("وضعیت و اطلاعات فنی")
        val tint = when (state.phase) {
            VpnPhase.CONNECTED -> Mint
            VpnPhase.CONNECTING, VpnPhase.RECONNECTING -> Color(0xFFFFC66D)
            VpnPhase.ERROR -> Danger
            VpnPhase.DISCONNECTED -> Muted
        }
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(statusLabel(state.phase), color = tint, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(state.message, color = Muted, fontSize = 12.sp)
                Divider(color = Color.White.copy(alpha = .08f))
                DetailRow("هسته شبکه", "Xray / libXray")
                DetailRow("پروفایل", selectedNode?.name ?: "انتخاب نشده")
                DetailRow("پروتکل", selectedNode?.protocol?.uppercase() ?: "—")
                DetailRow("میزبان", selectedNode?.host ?: "—")
                DetailRow("رابط شبکه", "Android VpnService / TUN")
            }
        }
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("آزمایش اینترنت از تونل", color = Color.White, fontWeight = FontWeight.Bold)
                Text("یک درخواست HTTPS سبک انجام می‌شود تا مشخص شود ترافیک همین برنامه از تونل به اینترنت می‌رسد یا نه.", color = Muted, fontSize = 11.sp, lineHeight = 17.sp)
                Button(
                    onClick = {
                        if (isTesting) return@Button
                        isTesting = true
                        probeMessage = null
                        scope.launch {
                            val result = withContext(Dispatchers.IO) { TunnelProbe.run() }
                            probeSuccess = result.reachable
                            probeMessage = result.detail + (result.endpoint?.let { " ($it)" } ?: "")
                            probeLatency = result.latencyMillis
                            isTesting = false
                        }
                    },
                    enabled = state.phase == VpnPhase.CONNECTED && !isTesting,
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    shape = RoundedCornerShape(13.dp)
                ) {
                    Text(if (isTesting) "در حال آزمایش…" else "شروع آزمایش اتصال", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                probeMessage?.let { message ->
                    Text(
                        message + (probeLatency?.let { "  •  ${it} ms" } ?: ""),
                        color = if (probeSuccess == true) Mint else Color(0xFFFFC66D),
                        fontSize = 11.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }
        SignatureMark()
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun SettingsScreen(profileCount: Int) {
    ScreenColumn {
        BrandHeader("تنظیمات برنامه")
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                SettingRow("نسخه برنامه", "1.1.0 • Android")
                Divider(color = Color.White.copy(alpha = .07f))
                SettingRow("تعداد پروفایل‌ها", profileCount.toString())
                Divider(color = Color.White.copy(alpha = .07f))
                SettingRow("ذخیره‌سازی", "رمزگذاری‌شده با Android Keystore")
                Divider(color = Color.White.copy(alpha = .07f))
                SettingRow("موتور اتصال", "XTLS / libXray")
            }
        }
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("درباره بپر VPN", color = Color.White, fontWeight = FontWeight.Bold)
                Text("کلاینت اندرویدی برای مدیریت پروفایل‌های سازگار با Xray و ایجاد تونل با Android VpnService.", color = Muted, fontSize = 12.sp, lineHeight = 19.sp)
                Text("برای استفاده از VPN حساب کاربری لازم نیست؛ برنامه مستقیماً از پروفایل سرور استفاده می‌کند.", color = Muted, fontSize = 11.sp, lineHeight = 17.sp)
            }
        }
        SignatureMark()
    }
}

@Composable
private fun SettingRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.End)
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("◈", color = Cyan, fontSize = 34.sp)
            Text(title, color = Color.White, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun SignatureMark() {
    Spacer(Modifier.height(3.dp))
    Text(
        "BEPAR  •  ANDROID CLIENT",
        modifier = Modifier.fillMaxWidth(),
        color = Color.White.copy(alpha = .24f),
        fontSize = 8.sp,
        letterSpacing = 2.sp,
        textAlign = TextAlign.Center
    )
}

private fun statusLabel(phase: VpnPhase): String = when (phase) {
    VpnPhase.CONNECTED -> "متصل"
    VpnPhase.CONNECTING -> "در حال اتصال"
    VpnPhase.RECONNECTING -> "در حال تغییر شبکه"
    VpnPhase.ERROR -> "خطا در اتصال"
    VpnPhase.DISCONNECTED -> "قطع شده"
}

private fun readConfigFile(context: android.content.Context, uri: android.net.Uri): String {
    val maxBytes = 15 * 1024 * 1024
    val input = context.contentResolver.openInputStream(uri)
        ?: throw IllegalStateException("خواندن فایل ممکن نشد.")
    val output = java.io.ByteArrayOutputStream()
    input.use { stream ->
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = stream.read(buffer)
            if (count < 0) break
            total += count
            require(total <= maxBytes) { "حجم فایل کانفیگ بیشتر از ۱۵ مگابایت است." }
            output.write(buffer, 0, count)
        }
    }
    return output.toString(Charsets.UTF_8.name())
}

private fun startVpnService(context: android.content.Context, nodeId: String) {
    val intent = Intent(context, BeparVpnService::class.java).apply {
        action = BeparVpnService.ACTION_CONNECT
        putExtra(BeparVpnService.EXTRA_NODE_ID, nodeId)
    }
    ContextCompat.startForegroundService(context, intent)
}
