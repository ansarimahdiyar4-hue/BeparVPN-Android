package com.bepar.vpn.core

import android.util.Base64
import libXray.LibXray
import org.json.JSONArray
import org.json.JSONObject
import com.bepar.vpn.data.NodeStore
import com.bepar.vpn.data.ServerNode
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

/** Adapter for the structured API exposed by the official XTLS/libXray Android AAR. */
object XrayApi {
    private const val API_VERSION = 3
    private const val MAX_SUBSCRIPTION_BYTES = 15 * 1024 * 1024

    fun invoke(method: String, payload: JSONObject = JSONObject()): JSONObject {
        val request = JSONObject()
            .put("apiVersion", API_VERSION)
            .put("method", method)
            .put("payload", payload)

        val rawResponse = LibXray.invoke(request.toString())
        val response = JSONObject(rawResponse)
        if (!response.optBoolean("success", false)) {
            val message = response.optString("error").ifBlank { "Xray operation failed" }
            throw IllegalStateException(message)
        }
        return response
    }

    /**
     * Accepts newline-separated share links, an Xray JSON profile, or an HTTPS
     * subscription URL. Legacy VMess QR-code links are converted locally because
     * current libXray intentionally accepts VMess-AEAD links, not the old format.
     */
    fun importNodes(input: String): List<ServerNode> {
        require(input.isNotBlank()) { "لینک یا متن کانفیگ خالی است." }
        val source = resolveSubscription(input.trim())
        require(source.toByteArray(Charsets.UTF_8).size <= MAX_SUBSCRIPTION_BYTES) {
            "حجم کانفیگ از ۱۵ مگابایت بیشتر است."
        }

        val trimmedSource = source.trim()
        val isJsonDocument = trimmedSource.startsWith("{") || trimmedSource.startsWith("[")
        val outbounds = if (isJsonDocument) {
            // An Xray JSON document is not a share-link string. Extract its proxy
            // outbounds locally and let the app build its own Android TUN config.
            parseJsonOutbounds(trimmedSource)
        } else {
            val lines = source.lines()
                .map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("//") }
            val converted = mutableListOf<JSONObject>()
            val remaining = mutableListOf<String>()

            for (line in lines) {
                if (line.startsWith("vmess://", ignoreCase = true)) {
                    val oldVmess = tryParseLegacyVmess(line)
                    if (oldVmess != null) {
                        converted += oldVmess
                        continue
                    }
                }
                remaining += line
            }

            if (remaining.isNotEmpty()) {
                val response = invoke(
                    "convertShareLinksToXrayJson",
                    JSONObject().put("text", remaining.joinToString("\n"))
                )
                val data = response.optJSONObject("data")
                    ?: throw IllegalArgumentException("خروجی مبدل سرور معتبر نیست.")
                val array = data.optJSONArray("outbounds")
                    ?: throw IllegalArgumentException("هیچ سرور سازگاری در متن پیدا نشد.")
                for (i in 0 until array.length()) {
                    array.optJSONObject(i)?.let(converted::add)
                }
            }
            converted
        }

        if (outbounds.isEmpty()) {
            throw IllegalArgumentException(
                "سروری پیدا نشد. لینک VLESS، VMess، Trojan، Shadowsocks، SOCKS، Hysteria2 یا فایل Xray JSON وارد کن."
            )
        }

        return outbounds.mapIndexed { index, outbound ->
            val protocol = outbound.optString("protocol", "xray").ifBlank { "xray" }
            val host = findHost(outbound) ?: ""
            val tag = outbound.optString("tag").trim()
            val display = tag
                .takeIf { it.isNotBlank() && !it.equals("proxy", true) }
                ?: listOf(protocol.uppercase(), host).filter { it.isNotBlank() }.joinToString(" • ")
                    .ifBlank { "سرور ${index + 1}" }

            ServerNode(
                id = NodeStore.newId(),
                name = display,
                protocol = protocol,
                host = host,
                outboundJson = outbound.toString()
            )
        }
    }

    private fun parseJsonOutbounds(json: String): List<JSONObject> {
        val parsed = org.json.JSONTokener(json).nextValue()
        val candidates = when (parsed) {
            is JSONObject -> {
                val outbounds = parsed.optJSONArray("outbounds")
                when {
                    outbounds != null -> (0 until outbounds.length()).mapNotNull(outbounds::optJSONObject)
                    parsed.optJSONObject("outbound") != null -> listOf(parsed.getJSONObject("outbound"))
                    parsed.has("protocol") && parsed.optJSONObject("settings") != null -> listOf(parsed)
                    else -> emptyList()
                }
            }
            is JSONArray -> (0 until parsed.length()).mapNotNull(parsed::optJSONObject)
            else -> emptyList()
        }

        val builtInProtocols = setOf("freedom", "blackhole", "dns", "loopback", "tun")
        val usable = candidates.filter { outbound ->
            val protocol = outbound.optString("protocol").trim()
            protocol.isNotBlank() && !builtInProtocols.contains(protocol.lowercase())
        }
        require(usable.isNotEmpty()) {
            "فایل JSON باید حداقل یک outbound سرور داشته باشد؛ کانفیگ کامل Xray را با outbound معتبر وارد کن."
        }
        return usable
    }

    private fun resolveSubscription(text: String): String {
        if (!text.startsWith("https://", ignoreCase = true) || text.contains('\n')) return text

        val connection = URL(text).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 12_000
            connection.readTimeout = 18_000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("Accept", "text/plain, application/json, */*")
            connection.setRequestProperty("User-Agent", "BeparVPN-Android/1.0")

            val code = connection.responseCode
            if (!connection.url.protocol.equals("https", ignoreCase = true)) {
                throw IllegalStateException("نشانی اشتراک نباید از HTTPS به HTTP تغییر مسیر دهد.")
            }
            if (code !in 200..299) throw IllegalStateException("دریافت اشتراک ناموفق بود (HTTP $code).")
            val stream = connection.inputStream
            val bytes = stream.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    require(total <= MAX_SUBSCRIPTION_BYTES) { "حجم اشتراک بیشتر از حد مجاز است." }
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            }
            return bytes.toString(Charsets.UTF_8).trim()
        } finally {
            connection.disconnect()
        }
    }

    private fun tryParseLegacyVmess(link: String): JSONObject? {
        return try {
            val body = link.substringAfter("vmess://", "").substringBefore('#').trim()
            if (body.isBlank()) return null
            val decoded = try {
                Base64.decode(body, Base64.DEFAULT).toString(Charsets.UTF_8)
            } catch (_: Exception) {
                Base64.decode(body, Base64.URL_SAFE or Base64.NO_WRAP).toString(Charsets.UTF_8)
            }
            val old = JSONObject(decoded)
            val address = old.optString("add").trim()
            val port = old.optString("port").toIntOrNull() ?: old.optInt("port", 0)
            val userId = old.optString("id").trim()
            if (address.isBlank() || port !in 1..65535 || userId.isBlank()) return null

            val transport = old.optString("net", "tcp").lowercase().ifBlank { "tcp" }
            // Do not silently rewrite removed HTTP/2 transports into a different protocol.
            if (transport !in setOf("tcp", "ws", "grpc", "kcp")) return null
            val stream = JSONObject().put("network", transport)
            val host = old.optString("host").trim()
            val path = old.optString("path").trim()
            val headerType = old.optString("type", "none").ifBlank { "none" }

            when (transport) {
                "tcp" -> {
                    if (headerType == "http") {
                        stream.put(
                            "tcpSettings",
                            JSONObject().put(
                                "header",
                                JSONObject().put(
                                    "type", "http"
                                ).put(
                                    "request",
                                    JSONObject()
                                        .put("version", "1.1")
                                        .put("method", "GET")
                                        .put("path", JSONArray().put(path.ifBlank { "/" }))
                                        .put("headers", JSONObject().put("Host", JSONArray().put(host.ifBlank { address })))
                                )
                            )
                        )
                    } else {
                        stream.put("tcpSettings", JSONObject().put("header", JSONObject().put("type", "none")))
                    }
                }
                "ws" -> {
                    val headers = JSONObject()
                    if (host.isNotBlank()) headers.put("Host", host)
                    stream.put(
                        "wsSettings",
                        JSONObject()
                            .put("path", path.ifBlank { "/" })
                            .put("headers", headers)
                    )
                }
                "grpc" -> {
                    stream.put(
                        "grpcSettings",
                        JSONObject()
                            .put("serviceName", path.trimStart('/'))
                            .put("multiMode", false)
                    )
                }
                "kcp" -> {
                    stream.put(
                        "kcpSettings",
                        JSONObject()
                            .put("mtu", 1350)
                            .put("tti", 20)
                            .put("uplinkCapacity", 5)
                            .put("downlinkCapacity", 20)
                            .put("congestion", false)
                            .put("readBufferSize", 2)
                            .put("writeBufferSize", 2)
                            .put("header", JSONObject().put("type", headerType))
                    )
                }
                else -> return null
            }

            val tls = old.optString("tls").equals("tls", true)
            if (tls) {
                val serverName = old.optString("sni").ifBlank { host.ifBlank { address } }
                stream.put("security", "tls")
                stream.put(
                    "tlsSettings",
                    JSONObject()
                        .put("serverName", serverName)
                        .put("allowInsecure", false)
                )
            } else {
                stream.put("security", "none")
            }

            val user = JSONObject()
                .put("id", userId)
                .put("alterId", old.optInt("aid", 0))
                .put("security", old.optString("scy", "auto").ifBlank { "auto" })

            val settings = JSONObject().put(
                "vnext",
                JSONArray().put(
                    JSONObject()
                        .put("address", address)
                        .put("port", port)
                        .put("users", JSONArray().put(user))
                )
            )

            val fragment = link.substringAfter('#', "").takeIf { it.isNotBlank() }
                ?.let { URLDecoder.decode(it, Charsets.UTF_8.name()) }
            JSONObject()
                .put("tag", fragment ?: "VMess $address:$port")
                .put("protocol", "vmess")
                .put("settings", settings)
                .put("streamSettings", stream)
        } catch (_: Exception) {
            null
        }
    }

    private fun findHost(value: Any?): String? {
        return when (value) {
            is JSONObject -> {
                val preferred = listOf("address", "server", "host", "add")
                for (key in preferred) {
                    val candidate = value.optString(key).trim()
                    if (candidate.isNotBlank() && candidate.length < 256) return candidate
                }
                val keys = value.keys()
                while (keys.hasNext()) {
                    val found = findHost(value.opt(keys.next()))
                    if (!found.isNullOrBlank()) return found
                }
                null
            }
            is JSONArray -> {
                for (i in 0 until value.length()) {
                    val found = findHost(value.opt(i))
                    if (!found.isNullOrBlank()) return found
                }
                null
            }
            else -> null
        }
    }
}
